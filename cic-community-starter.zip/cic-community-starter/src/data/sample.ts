export type AgendaItem = { day: string; month: string; title: string; meta: string; urgency?: string }
export const agenda: AgendaItem[] = [
  { day: '21', month: 'NOV', title: 'Pengumpulan Tugas Bahasa Indonesia', meta: '23.59 WIB · Bahasa Indonesia', urgency: 'Deadline besok' },
  { day: '23', month: 'NOV', title: 'Zoom Pengantar Manajemen', meta: '19.00 WIB · Pertemuan online' },
  { day: '28', month: 'NOV', title: 'Deadline Tugas Akuntansi', meta: '23.59 WIB · Akuntansi' },
]
export const discussions = [
  { category: 'AKUNTANSI', title: 'Ada yang bisa bantu jelasin jurnal penyesuaian?', body: 'Aku masih bingung membedakan beban dibayar di muka dan beban yang masih harus dibayar.', author: 'Anonim', time: '35 menit lalu', replies: 3 },
  { category: 'BAHASA INDONESIA', title: 'Referensi materi untuk tugas argumentasi', body: 'Ada rekomendasi sumber yang mudah dipahami?', author: 'Naya', time: '2 jam lalu', replies: 6 },
]
export const notes = [
  { color: 'yellow', author: 'ANONIM', time: '20.43', text: 'Semangat UTS semuanya! Jangan lupa istirahat juga ya 😭', likes: 4, replies: 2 },
  { color: 'green', author: 'NAYA', time: '21.10', text: 'Belajar bareng yuk! Ada yang mau diskusi Akuntansi?', likes: 2, replies: 5 },
]
export const summaries = [
  { category: 'BAHASA INDONESIA', title: 'Memahami Teks Argumentasi', meta: 'Rangkuman · Pertemuan 5 · Contributor' },
  { category: 'AKUNTANSI', title: 'Pengenalan Jurnal Penyesuaian', meta: 'Rangkuman · Pertemuan 4 · Contributor' },
]
