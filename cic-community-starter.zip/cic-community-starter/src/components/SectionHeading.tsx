type Props = { number: string; title: string; link?: string }
export default function SectionHeading({ number, title, link }: Props) {
  return <div className="section-heading"><h2><span>{number} /</span> {title}</h2>{link && <a href="#">{link} ↗</a>}</div>
}
